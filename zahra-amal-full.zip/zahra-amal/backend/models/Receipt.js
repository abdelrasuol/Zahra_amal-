// File: backend/models/Receipt.js
