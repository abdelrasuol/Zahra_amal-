// File: backend/models/Product.js
