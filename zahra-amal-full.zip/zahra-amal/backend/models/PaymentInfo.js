// File: backend/models/PaymentInfo.js
