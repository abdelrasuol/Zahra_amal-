// File: backend/models/Rating.js
