// File: backend/models/Cart.js
