// File: backend/controllers/securityController.js
