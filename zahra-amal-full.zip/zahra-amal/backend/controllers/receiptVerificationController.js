// File: backend/controllers/receiptVerificationController.js
