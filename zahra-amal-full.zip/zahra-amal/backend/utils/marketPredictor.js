// File: backend/utils/marketPredictor.js
