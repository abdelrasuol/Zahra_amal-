// File: backend/utils/twoFactorAuth.js
