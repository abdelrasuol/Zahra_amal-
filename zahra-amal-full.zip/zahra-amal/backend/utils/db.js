// File: backend/utils/db.js
