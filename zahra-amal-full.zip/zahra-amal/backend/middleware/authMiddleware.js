// File: backend/middleware/authMiddleware.js
