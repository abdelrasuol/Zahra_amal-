// File: backend/routes/receiptRoutes.js
