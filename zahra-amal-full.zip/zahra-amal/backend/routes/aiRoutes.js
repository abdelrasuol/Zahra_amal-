// File: backend/routes/aiRoutes.js
