// File: backend/routes/securityRoutes.js
