// File: backend/routes/authRoutes.js
