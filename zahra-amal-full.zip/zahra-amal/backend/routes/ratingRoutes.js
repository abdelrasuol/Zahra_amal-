// File: backend/routes/ratingRoutes.js
