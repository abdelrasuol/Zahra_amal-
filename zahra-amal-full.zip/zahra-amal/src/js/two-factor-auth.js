// File: src/js/two-factor-auth.js
