// File: src/js/receipt.js
