// File: backend/controllers/productController.js
