// File: backend/controllers/messageController.js
