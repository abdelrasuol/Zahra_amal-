// File: backend/controllers/authController.js
