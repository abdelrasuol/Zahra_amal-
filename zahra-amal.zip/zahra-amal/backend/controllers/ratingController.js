// File: backend/controllers/ratingController.js
