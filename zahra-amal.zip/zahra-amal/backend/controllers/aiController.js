// File: backend/controllers/aiController.js
