// File: backend/controllers/cartController.js
