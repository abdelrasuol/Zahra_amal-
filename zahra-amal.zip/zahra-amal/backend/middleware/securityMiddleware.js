// File: backend/middleware/securityMiddleware.js
