// File: backend/middleware/errorHandler.js
