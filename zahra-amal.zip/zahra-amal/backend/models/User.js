// File: backend/models/User.js
