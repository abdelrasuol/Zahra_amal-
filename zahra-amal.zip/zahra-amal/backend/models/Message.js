// File: backend/models/Message.js
