// File: backend/utils/security.js
