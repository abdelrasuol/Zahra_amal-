// File: backend/utils/receiptVerifier.js
