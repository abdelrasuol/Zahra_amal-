// File: backend/routes/productRoutes.js
